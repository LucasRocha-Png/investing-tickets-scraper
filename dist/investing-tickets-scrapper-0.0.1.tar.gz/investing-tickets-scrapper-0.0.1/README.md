# investing-tickets-scrapper
This package scraps all tickets available from "investing.com" site
