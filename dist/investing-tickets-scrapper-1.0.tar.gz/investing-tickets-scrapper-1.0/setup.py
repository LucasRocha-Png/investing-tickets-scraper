from setuptools import setup, find_packages


VERSION = '1.0'
DESCRIPTION = 'Scraps stocks tickets from "Investing.com" using Selenium'
LONG_DESCRIPTION = 'Scraps stocks tickets from "Investing.com" using Selenium'

# Setting up
setup(
    name="investing-tickets-scrapper",
    version=VERSION,
    author="Lucas Rocha",
    author_email="lucasrocha.png@gmail.com",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=LONG_DESCRIPTION,
    packages=find_packages(),
    install_requires=['pandas', 'selenium'],
    keywords=['python', 'tickers', 'index', 'stocks', 'exchange', 'investing'],
    classifiers=[
        "Development Status :: 2 - In Work",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)