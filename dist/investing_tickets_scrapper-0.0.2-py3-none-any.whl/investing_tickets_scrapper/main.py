from investing_tickets_scrapper.investing_tickets_scrapper import Scrapper

Scrapper()