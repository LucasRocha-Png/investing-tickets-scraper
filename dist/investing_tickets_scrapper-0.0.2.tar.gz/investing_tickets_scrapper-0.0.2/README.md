# investing-tickets-scrapper
#### IN WORK!
#### This package scraps all tickets available from "investing.com" site
